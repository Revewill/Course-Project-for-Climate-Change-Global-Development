Overleaf：上传整个 ZIP 新建项目，主文件选 main.tex，编译器选 XeLaTeX，点击重新编译。
本地：在解压目录运行 latexmk -xelatex main.tex。也可依次运行 xelatex main、bibtex main、xelatex main、xelatex main。
main.tex：修改封面姓名、学号、标题及文末 AI 使用说明。
body.tex：替换示例段落。空行分段。用 \cite{ipcc} 插入上标引文；用 \original{中文判断句} 添加可换行的下划线。
references.bib：已含四条示例文献，按最终正文补全；文末自动按首次引用顺序列出。
figure1.tex、figure2.tex：修改图注。用图~\ref{fig:exposure}、图~\ref{fig:decision}交叉引用。
figures/：替换同名 PDF 就能更新图片。两张组图各占一页，位置由正文中的 \input 和浮动排版决定。
源文件使用 UTF-8；正文中百分号写作 \%，下划线写作 \_。正文按课程要求控制在1500–2000字。
